﻿using System;
using adisware.juipp.Events.Arguments;

namespace $rootnamespace$.Behaviors
{
    public partial class OpenDefaultBehavior
    {
    }
}
